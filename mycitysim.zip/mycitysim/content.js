"use strict";
// make Cyberjaya Great Again!

const SAVE_NS = "mycitysim";
const MARK = "kaizen.pending";
const GUARD = "kaizen.autoloads";
const MAX_RELOADS = 3;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const log = (...a) => console.log("[kaizen]", ...a);

function setPin(on) {
  try {
    if (on) localStorage.setItem(POP_PIN_KEY, String(POP));
    else localStorage.removeItem(POP_PIN_KEY);
  } catch {}
}

// patch.js runs in the page at document_start, where chrome.storage is not
// reachable, so the disasters switch has to be mirrored into localStorage. It
// gates putting the device's weather preference back on (weather off = no
// floods/storms, whatever social.bencana says).
function setBencana(on) {
  try {
    if (on) localStorage.setItem("kaizen.bencana", "1");
    else localStorage.removeItem("kaizen.bencana");
  } catch {}
}


function readMirror() {
  try {
    const raw = localStorage.getItem(MIRROR_KEY);
    const m = raw ? JSON.parse(raw) : null;
    return m && m.state && typeof m.state === "object" ? m : null;
  } catch { return null; }
}
function writeMirror(state) {
  try { localStorage.setItem(MIRROR_KEY, JSON.stringify({ at: Date.now(), state })); } catch {}
}
async function mirrorNow() {
  try { writeMirror(await chrome.storage.local.get(null)); } catch {}
}

async function hydrate() {
  const cur = await chrome.storage.local.get("master");
  if (cur.master !== undefined) return false;
  const m = readMirror();
  if (!m) return false;
  await chrome.storage.local.set(m.state);
  log("storage was empty — switches and snapshots restored from the page mirror");
  return true;
}

function saveKey() {
  const slot = Number(localStorage.getItem(`${SAVE_NS}.slot`) || 1);
  return slot === 1 ? `${SAVE_NS}.save.v1` : `${SAVE_NS}.save.v1.${slot}`;
}

async function getState() {
  const st = await chrome.storage.local.get(["master", "rank", "money", "unlock", "tier", "pop",
                                            "lm", "lmN", "localSnap", "bencana", "politik"]);
  return {
    master: !!st.master,
    bencana: !!st.bencana,
    politik: st.politik !== false,
    rank: st.rank !== false,
    money: st.money !== false,
    unlock: st.unlock !== false,
    tier: TIERS.includes(st.tier) ? st.tier : null,
    pop: !!st.pop,
    lm: LANDMARKS.some((l) => l.id === st.lm) ? st.lm : null,
    lmN: Math.min(LM_MAX, Math.max(1, Number(st.lmN) || 1)),
    localSnap: st.localSnap || null,
  };
}

function uidNow() {
  try {
    const k = Object.keys(localStorage).find((x) => x.includes("-auth-token"));
    if (!k) return null;
    const raw = JSON.parse(localStorage.getItem(k));
    const tok = raw && (raw.access_token || (raw.currentSession && raw.currentSession.access_token));
    if (!tok) return null;
    const part = String(tok).split(".")[1].replace(/-/g, "+").replace(/_/g, "/");
    return JSON.parse(atob(part)).sub || null;
  } catch { return null; }
}

function reloads() {
  try { return Number(sessionStorage.getItem(GUARD) || 0); } catch { return 0; }
}
function countReload() {
  try { sessionStorage.setItem(GUARD, String(reloads() + 1)); } catch {}
}

// the console's own writes are already on disk; only the boot replay is missing
function writeAndReload(key, raw) {
  localStorage.setItem(key, raw);
  localStorage.setItem(MARK, JSON.stringify({ key, data: raw, at: Date.now() }));
  countReload();
  location.reload();
}

async function tick() {
  const st = await getState();

  let hadPin = false;
  try { hadPin = localStorage.getItem(POP_PIN_KEY) !== null; } catch {}
  const wantPin = st.master && st.pop;
  setPin(wantPin);
  setBencana(st.master && st.bencana);
  const key = saveKey();
  const raw = localStorage.getItem(key);
  if (!raw) return;                        // no city written yet — the game will write one
  const save = parseSave(raw);
  if (!save) return;
  const uid = uidNow();
  const spec = { ...st, lm: st.lm ? { id: st.lm, n: st.lmN } : null };
  const snap = st.localSnap;
  const owned = snap && (!snap.uid || snap.uid === uid) && (!save || sameCity(parseSave(snap.raw), save));

  if (!st.master) {
    // auto-revert once, and only if this save is currently carrying a patch
    if (snap && owned && raw !== snap.raw && reloads() < MAX_RELOADS) {
      const pristine = parseSave(snap.raw);
      const carrying = save.money === MONEY ||
        (save.unlocked || []).length > ((pristine && pristine.unlocked) || []).length ||
        (pristine && pristine.tier !== save.tier) ||
        LANDMARKS.some((l) =>
          Object.values(save.buildings || {}).filter((b) => b && b.kind === 5 && b.svc === l.id).length >
          Object.values((pristine && pristine.buildings) || {}).filter((b) => b && b.kind === 5 && b.svc === l.id).length);
      if (carrying) {
        log("master off — restoring the pristine save");
        writeAndReload(snap.key || key, snap.raw);
      }
    }
    return;
  }

  if (hadPin && !wantPin && owned && save.stats && save.stats.pop === POP && reloads() < MAX_RELOADS) {
    log("population pin off — restoring the pristine save");
    writeAndReload(snap.key || key, snap.raw);
    return;
  }

  if (!owned) {
    const fresh = { uid, key, raw, tier: save.tier ?? null, ...cityId(save) };
    await chrome.storage.local.set({ localSnap: fresh });
    await mirrorNow();
  } else if (isPatched(save, spec)) {
    try { sessionStorage.removeItem(GUARD); } catch {}
    return;                    
  }

  if (reloads() >= MAX_RELOADS) { log("reload budget spent — leaving the save alone"); return; }
  const patched = transformSave(parseSave(raw), spec);
  
  const copies = (o) => st.lm
    ? Object.values(o.buildings || {}).filter((b) => b && b.kind === 5 && b.svc === st.lm).length : 0;
  if (st.lm && copies(patched) <= copies(save)) {
    log(`no free tiles for another ${st.lm} copy (${copies(save)}/${st.lmN}) — leaving the save alone`);
    return;
  }
  log("applying", Object.keys(spec).filter((k) => spec[k]).join(","));
  writeAndReload(key, JSON.stringify(patched));
}

(async () => {

  log(`${UNLOCK_NAMES.length} gated catalog names loaded`);
  await hydrate();
  // keep backup1
  await mirrorNow();
   // keep backup2
  for (let i = 0; i < 40; i++) {
    try { await tick(); } catch (e) { log("tick failed", e); }
    await sleep(i < 10 ? 500 : 2000);
  }
})();
