
(() => {
  const MARK = "kaizen.pending";
  const PIN = "kaizen.pop";
  const XP = "kaizen.politik";

  try {
    const raw = localStorage.getItem(MARK);
    if (raw) {
      const rec = JSON.parse(raw);
      if (rec && typeof rec.key === "string" && typeof rec.data === "string") {
        localStorage.setItem(rec.key, rec.data);
      }
      localStorage.removeItem(MARK);
    }
  } catch {}

  // ---- Politikal Disaster (0.3.0) ----
  // The expansion is owned from two places, and "Turn on Politics" checks both
  // before it writes social.pol into the save:
  //
  //   Tf(id) -> id is in localStorage["mycitysim.owns"], read once while the
  //             bundle initialises (a comma list, snapshot taken at module load)
  //   QM(id) -> id is in the account's my_expansions() list, fetched over fetch()
  //             and required on top of Tf on the web (native Android always owns it)
  //
  // So set the key before the bundle reads it, and rewrite the single RPC response
  // that answers the account. Without both, the toast is "This expansion isn't on
  // your account" (account known) or "Go online once to confirm" (not fetched yet).
  // On by default: only an explicit "0" from the popup turns it off, so a fresh
  // profile owns the expansion without visiting the popup first.
  let wantXp = true;
  try { wantXp = localStorage.getItem(XP) !== "0"; } catch {}
  if (wantXp) {
    // any later read of the owns list still answers yes
    try {
      const get = Storage.prototype.getItem;
      Storage.prototype.getItem = function (k) {
        const v = get.call(this, k);
        if (k !== "mycitysim.owns") return v;
        const list = (v || "").split(",").filter(Boolean);
        return list.includes("politik") ? v : list.concat("politik").join(",");
      };
    } catch {}
    try {
      const owns = (localStorage.getItem("mycitysim.owns") || "").split(",").filter(Boolean);
      if (!owns.includes("politik")) localStorage.setItem("mycitysim.owns", owns.concat("politik").join(","));
    } catch {}

    const nativeFetch = window.fetch;
    if (typeof nativeFetch === "function" && !nativeFetch.__kaizenXp) {
      const hooked = function (input) {
        const answer = nativeFetch.apply(this, arguments);
        try {
          const url = typeof input === "string" ? input : (input && input.url) || "";
          if (/\/rpc\/my_expansions(?:\?|$)/.test(url)) {
            return answer.then(async (res) => {
              if (!res || !res.ok) return res;
              const list = await res.clone().json().catch(() => null);
              if (!Array.isArray(list) || list.includes("politik")) return res;
              return new Response(JSON.stringify(list.concat("politik")), {
                status: res.status,
                statusText: res.statusText,
                headers: { "Content-Type": "application/json" },
              });
            });
          }
        } catch {}
        return answer;
      };
      hooked.__kaizenXp = true;
      window.fetch = hooked;
    }
  }

  // ---- Disasters (bencana) need weather ----
  // The pause-menu Disasters card and the HUD both short-circuit on save.weather.off:
  //
  //   JHe: if (e.weather.off) return "Off: weather is off on this device."
  //   MP:  social.bencana === "on" && !e.weather.off && !e.showcase && At(e) >= xt.TIER
  //
  // and the game keeps that flag in sync with the device preference stored in
  // localStorage["mycitysim.weather"] ("off" disables the whole weather system:
  // no rain, storms, heat or haze, and therefore no floods, tornadoes or collapses).
  // content.js mirrors the bencana switch here; when it is on, put weather back on
  // before the bundle reads the preference. The pause-menu Weather chip still works
  // for the current session - it writes "off" and sets weather.off itself.
  let wantBn = false;
  try { wantBn = localStorage.getItem("kaizen.bencana") === "1"; } catch {}
  if (wantBn) {
    try { localStorage.setItem("mycitysim.weather", "on"); } catch {}
  }

  let pin = 0;
  try { pin = Number(localStorage.getItem(PIN)) || 0; } catch { return; }
  if (!(pin > 0)) return;

  const isSave = (o) =>
    !!o && typeof o === "object" &&
    Array.isArray(o.bld) &&
    !!o.buildings && typeof o.buildings === "object" &&
    !!o.stats && typeof o.stats === "object";

  const parse = JSON.parse;
  if (parse.__kaizenPin) return;
  const pinParse = function (text, reviver) {
    const v = parse.call(this, text, reviver);
    if (!isSave(v)) return v;
    let stats = v.stats;
    stats.pop = pin;
    Object.defineProperty(v, "stats", {
      configurable: true,
      enumerable: true,
      get() { return stats; },
      set(next) { if (next && typeof next === "object") stats = { ...next, pop: pin }; },
    });
    return v;
  };
  pinParse.__kaizenPin = pin;
  JSON.parse = pinParse;
})();
